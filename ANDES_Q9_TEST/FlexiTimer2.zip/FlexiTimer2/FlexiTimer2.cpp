#include <FlexiTimer2.h>

unsigned long FlexiTimer2::time_units;
void (*FlexiTimer2::func)();
volatile unsigned long FlexiTimer2::count;
volatile char FlexiTimer2::overflowing;
volatile unsigned int FlexiTimer2::tcnt2;

void (*callback)();

extern "C" {
	void timer4_irq_handler() {
	void (*intr)();
		intr = callback;
		intr();
	}
}

void FlexiTimer2::set(unsigned long ms, void (*f)()) {
	uint32_t ms_time_unit;

	ms_time_unit = PCLKFREQ / 1000;

	TIMER_Init(TIMER4, TIMER_32, 0, (ms * ms_time_unit));

	callback = f;
}

void FlexiTimer2::start() {
	count = 0;
	overflowing = 0;

	TIMER_EnableInt(TIMER4);
	TIMER_Start(TIMER4);
}

void FlexiTimer2::_overflow() {
}
